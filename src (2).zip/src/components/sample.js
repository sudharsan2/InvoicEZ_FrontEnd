

const Sample=()=>{
return <div>hi</div>

}
export default Sample;